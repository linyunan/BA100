#ifndef __NV080C_H__
#define __NV080C_H__

#define nvc_sda P0_0 

void Init_NV080C();
void send_line(uint8);

#endif




